export default function Page() {
  return (
    <div className="flex min-h-screen items-center justify-center">
      <img src="/v0-orbit.svg" alt="v0 Orbit Animation" width={320} height={320} />
    </div>
  )
}
